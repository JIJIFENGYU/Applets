// weibo/pages/writeweibo/writeweibo.js
import {
  getUUID,
  getExt
} from "../../utils/util.js";
const app = getApp();
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    location: null,
    isShowDelete: false,
    tempImages: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    const type = options.type;
    this.setData({
      type: type
    });
    const pages = getCurrentPages();
    const indexPage = pages[0];
    if (type == 1) {      
      const tempImages = indexPage.data.tempImages;
      this.setData({
        tempImages: tempImages
      })
      console.log("========="+tempImages.length);
    } else if (type == 2) {
      const tempVideo = indexPage.data.tempVideo;
      this.setData({
        tempVideo: tempVideo
      })
    }    
    this.initImageSize();

  },

  

  openLocationPage: function() {
    const that = this;
    wx.chooseLocation({
      success: function(res) {
        delete res.errMsg;
        that.setData({
          location: res
        })
      },
    })
  },

  onLocationTap: function(event) {
    const that = this;
    wx.getSetting({
      success: res => {
        const isLocation = res.authSetting['scope.userLocation'];
        if (isLocation) {
          that.openLocationPage();
        } else {
          wx.authorize({
            scope: 'scope.userLocation',
            success: res => {
              if (res.name) {
                that.openLocationPage();
              }
            }
          })
        }
      }
    })
  },

  onSubmitEvent: function(event) {
    const that = this;
    const content = event.detail.value.content;
    if (!content) {
      wx.showToast({
        title: '请输入微博内容！',
        icon: "none"
      });
      return;
    }
    const location = this.data.location;
    const author = app.globalData.userInfo;
    const systemInfo = wx.getSystemInfoSync();
    let model = systemInfo.model;
    model = model.replace(/<.*>/);
    const type = that.data.type;
    const weibo = {
      content: content,
      location: location,
      author: author,
      device: model,
      type: type
    }
    wx.showLoading({
      title: '正在发表中...',
    })
    if (that.data.type == 1 && that.data.tempImages.length > 0) {      
      const successImage = [];
      that.data.tempImages.forEach((value, index) => {
        const cloudPath = that.getCloudPath(value);
        wx.cloud.uploadFile({
          filePath: value,
          cloudPath: cloudPath,
          success: res => {
            successImage.push(res.fileID);
            if (successImage.length == that.data.tempImages.length) {
              weibo.fileList = successImage;
              that.publishWeibo(weibo);
            }
          }
        })
      })
    } else if (that.data.type == 2 && that.data.tempVideo) {
      const cloudPath = that.getCloudPath(that.data.tempVideo);
      wx.cloud.uploadFile({
        filePath: that.data.tempVideo,
        cloudPath: cloudPath,
        success: res => {
          weibo.video = res.fileID;
          that.publishWeibo(weibo);
        }
      })
    } else {
      that.publishWeibo(weibo);
    }
  },

  publishWeibo: function(weibo) {
    wx.cloud.callFunction({
      name: "contentCheck",
      data: weibo,
      success: res => {
        wx.hideLoading();
        const _id = res.result._id;
        if (_id) {
          wx.showToast({
            title: "发送成功!"
          });
          setTimeout(function() {
            wx.navigateBack({
              
            })
          },1200)
        } else {
          wx.showToast({
            title: res.result.errmsg,
            icon: "none"
          })
        }
      }
    })
  },

  initImageSize: function() {
    const windowWidth = wx.getSystemInfoSync().windowWidth;
    const imageSize = (windowWidth - 60 - 2.5 * 3) / 3;
    this.setData({
      imageSize: imageSize
    })
  },

  onAddImage: function(event) {
    const that = this;
    wx.chooseImage({
      success: function(res) {
        const tempImages = res.tempFilePaths;
        const oldImages = that.data.tempImages;
        const newImages = oldImages.concat(tempImages);
        that.setData({
          tempImages: newImages
        })
      },
    })
  },

  onRemoveImage: function(event) {
    const index = event.target.dataset.index;
    const tempImages = this.data.tempImages;
    tempImages.splice(index, 1);
    this.setData({
      tempImages: tempImages
    })
  },

  getCloudPath: function(fileName) {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1;
    const day = today.getDate();
    const cloudPath = "weibos/" + year + "/" + month + "/" + day + "/" + getUUID() + "." + getExt(fileName);
    return cloudPath;
  },

  onImageTap: function(event) {
    const that = this;
    const index = event.target.dataset.index;
    const current = that.data.tempImages[index];
    wx.previewImage({
      urls: that.data.tempImages,
      current: current
    })
  }
})