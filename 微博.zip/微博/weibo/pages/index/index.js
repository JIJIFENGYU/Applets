// weibo/pages/index/index.js
const app = getApp();
const db = wx.cloud.database();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    hasmore: true,
    weibos:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadWeibos();
  },

  onPullDownRefresh: function() {
    this.loadWeibos(0);
  },
  // 页面滚动到最底部
  onReachBottom: function() {
    this.loadWeibos(this.data.weibos.length,1);
  },

  loadWeibos: function(start = 0,type = 0) {
    const that = this;
    wx.cloud.callFunction({
      name:"getWeibos",
      data: {
        start: start
      }
    }).then(res => {
      //console.log(res);
      const weibos = res.result;
      let hasmore = true;
      if (!weibos || weibos.length < 5) {
        hasmore = false;
        if (!weibos) {
          return;
        }
      }
      // weibos.forEach((value, index) => {
      //   value.create_time = value.create_time.getTime();
      // });
      let newData = [];
      if (type == 1) {
        newData = that.data.weibos.concat(weibos);
      } else {
        newData = weibos;
      };      
      that.setData({
        weibos: newData,
        hasmore: hasmore
      })
    })
  },

  onShow: function() {
    this.loadWeibos();
    wx.pageScrollTo(0);
  },

  

  onWriteWeiboTap: function (event) {
    const that = this;
    if (app.isLogin()) {
      wx.showActionSheet({
        itemList: ["文字","照片","视频"],
        success: res => {
          const tapIndex = res.tapIndex;
          if (tapIndex == 0) {
            wx.navigateTo({
              url: '../writeweibo/writeweibo?type=' + tapIndex,
            })  
          } else if (tapIndex == 1) {
            wx.chooseImage({
              success: function(res) {
                const tempImages = res.tempFilePaths;
                that.setData({
                  tempImages: tempImages
                })   
                wx.navigateTo({
                  url: '../writeweibo/writeweibo?type=' + tapIndex,
                })               
              },
            })
          } else if (tapIndex == 2) {
            wx.chooseVideo({
              success: res => {
                const tempVideo = res.tempFilePath;
                that.setData({
                  tempVideo: tempVideo
                })
                wx.navigateTo({
                  url: '../writeweibo/writeweibo?type=' + tapIndex,
                })  
              }
            })
          }
                  
        }
      })
    } else {
      wx.navigateTo({
        url:"../login/login"
      })
    }
  },

  

  
})