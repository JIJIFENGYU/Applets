const app = getApp();


Page({
  data: {
    password: '',
    showItem: false,
    setPhraseNum: 1,
    title: '首次使用，请设置手势密码',
    passwordTemp: '',
    showError: false,
  },
  onEnd(data) {    
    if (this.data.setPhraseNum === 0) {
      if (data.detail.toString() === this.data.password.toString()) {
        this.setData({
          showItem: true,
        });
        this.loadWeibos();
      } else {
        wx.showToast({
          title: '密码错误，请重试',
          icon: 'none',
          duration: 1000,
        })
      }
    } else if (this.data.setPhraseNum === 1) {
      this.setData({
        passwordTemp: data.detail.toString(),
        setPhraseNum: 2,
        title: '请再次输入手势密码'
      })
    } else {
      if (data.detail.toString() === this.data.passwordTemp) {
        const  password = this.data.passwordTemp;
        const  openId = app.globalData.userInfo.openId;
        //console.log("=====" + password);
        wx.cloud.callFunction({
          name: 'setUserInfo',
          data: {            
            openId: openId,
            password: password
          },
          success: (res) => {
            //console.log("====="+JSON.stringify(res.result));
            wx.showToast({
              title: '设置成功',
              icon: 'none',
              duration: 1000
            });
            app.globalData.userInfo.password = password;
            this.setData({
              password: password.split(','),
              title: '请输入手势密码',
              setPhraseNum: 0,
              showError: true,
            })
          }
        })
      } else {
        wx.showToast({
          title: '两次设置不一致，请重新录入！',
          icon: 'none',
          duration: 1000
        });
        this.setData({
          passwordTemp: [],
          title: '请设置手势密码',
          setPhraseNum: 1
        })
      }
    }
  },

  onLoad: function () {
    if (!app.globalData.userInfo) {
      wx.navigateTo({
        url: "../login/login"
      })
      return
    } 
    if ('password' in app.globalData.userInfo) {
      const password = app.globalData.userInfo.password;
      this.setData({
        password: password.split(','),
        setPhraseNum: 0,
        title: '请输入手势密码',
        showError: true,
      })
    }
  },

  onPullDownRefresh: function () {
    this.loadWeibos();
  },

  onHide: function () {
    this.setData({
      showItem: false
    })
  },  

  loadWeibos: function (start = 0, type = 0) {
    const that = this;
    const openId = app.globalData.userInfo.openId;
    wx.showLoading({
      title: '加载中……'
    })
    wx.cloud.callFunction({
      name: "getWeibos",
      data: {
        start: start,
        status: 2,
        openId: openId,
        num: 0
      }
    }).then(res => {
      const weibos = res.result;   
      console.log("====="+JSON.stringify(weibos));  
      that.setData({
        weibos: weibos
      })
    });
    wx.hideLoading();
  },

  onDeleteWeiboTap: function (event) {
    const weiboId = event.detail.weiboId;
    const weibos = this.data.weibos;
    let deleteIndex = 0;
    weibos.forEach((value, index) => {
      if (value._id == weiboId) {
        deleteIndex = index;
      }
    });
    weibos.splice(deleteIndex, 1);
    this.setData({
      weibos: weibos
    })
  },


  
})



