// pages/detail/detail.js
const db = wx.cloud.database();
const _ = db.command;
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mask:false,
    inputValue:"",
    page_top:0,
    bottom_fixed:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const index = options.index;
    const pages = getCurrentPages();
    const indexPage = pages[0];
    const weibos = indexPage.data.weibos;
    const weibo = weibos[index];
    const windowHeight = wx.getSystemInfoSync().windowHeight;
    this.setData({
      weibo: weibo,
      windowHeight: windowHeight
    });
    this.loadComment();
  },

  onShow: function() {
    const that = this;
    var query = wx.createSelectorQuery();
    //选择id
    query.select('#page-top').boundingClientRect()
    query.exec(function (res) {
      const page_top = res[0].height;
      that.setData({
        page_top: page_top
      })
    })
  },

  // onPageScroll: function(e) {
  //   var current_top = e.scrollTop;
  //   let currentFixed = false;
  //   if (current_top > this.data.page_top) {
  //     currentFixed = true;
  //   }
  //   this.setData({
  //     bottom_fixed: currentFixed
  //   })
  // },

  scrollTopFun: function(event) {
    let current_top = event.detail.scrollTop;
    let currentFixed = false;
    if (current_top > this.data.page_top) {
      currentFixed = true;
    }
    this.setData({
      bottom_fixed: currentFixed
    })
  },

  loadComment: function() {
    const that = this;
    const weiboId = that.data.weibo._id;
    wx.cloud.callFunction({
      name: "getComments",
      data: {
        weiboId: weiboId
      }
    }).then(res => {
      //console.log(res);
      const comments = res.result;
      console.log(comments);
      // 经过了云函数，这里不再需要转换了
      // comments.forEach((value, index) => {
      //   value.create_time = value.create_time.getTime();
      // })
      that.setData({
        comments: comments
      })      
    })
    
  },

  onSend: function(event) {
    console.log(event);
  },

  onFocus: function(event) {
    this.setData({
      mask: true
    })
  },

  onBlur: function(event) {
    this.setData({
      mask: false
    })
  },

  clearInput: function() {

  },

  onConfirm: function(event) {
    const content = event.detail.value;
    const that = this;
    db.collection("comment").add({
      data: {
        content: content,
        author: app.globalData.userInfo,
        create_time: db.serverDate(),
        weiboid: that.data.weibo._id
      }
    }).then(res => {
      const weibo = that.data.weibo;
      let newcomment;
      if (weibo.comment) {
        newcomment = weibo.comment+1;       
      } else {
        newcomment = 1;
      }
      weibo.comment = newcomment;
      console.log("======"+newcomment);
      wx.cloud.callFunction({
        name: "addComment",
        data: {
          weiboId: weibo._id
        },
        success: res => {
          weibo.comment = newcomment;
        }
      })
      const comment = {
        "_id":res.id,
        "content": content,
        "author": app.globalData.userInfo,
        "create_time": (new Date()).getTime()
      };
      let comments = that.data.comments;
      if (comments) {
        comments.splice(0,0,comment);
      } else {
        comments = [comment];
      }
      that.setData({
        comments: comments,
        inputValue: "",
        weibo: weibo
      })
    })
  },

  


  

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

 
})