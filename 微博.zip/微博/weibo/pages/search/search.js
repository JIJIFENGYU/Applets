// pages/search/search.js
import {
  network
} from "../../utils/network.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    histories: [],
    subjects:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.setNavigationBarColor({
      frontColor: "#ffffff",
      backgroundColor: '#41be57'
    })
    wx.setNavigationBarTitle({
      title: '电影搜索',
    })
    var that = this;
    wx.getStorage({
      key: 'searched',
      success: function(res) {
        var data = res.data;
        that.setData({
          histories: data
        })
      },
    })
  },

  onSearchEvent: function(event) {
    var value = event.detail.value;
    var that = this;
    if(value) {
      network.getSearch({
        q: value,
        success: function (subjects) {
          that.setData({
            subjects: subjects
          })
        }
      })
    } else {
      that.setData({
        subjects: []
      })
    }   
  },

  onItemTapEvent: function(event) {
    var that = this;
    var id = event.currentTarget.dataset.id;
    var title = event.currentTarget.dataset.title;
    var histories = [];
    var isExist = false;
    histories = that.data.histories;
    for (var i = 0; i < histories.length; i++) {
      var movie = histories[i];
      if (movie.id == id) {
        isExist = true;
        break;
      }
    }
    if (!isExist) {
      histories.push({
        title: title,
        id: id
      });
      wx.setStorage({
        key: 'searched',
        data: histories,
        success: function() {
          console.log("保存成功")
        }
      })
    }
    wx.navigateTo({
      url: '/pages/detail/detail?type=movie&id=' + id,
    })
  },

  onClearEvent: function(event) {
    wx.removeStorage({
      key: 'searched',
      success: function(res) {},
    })
    this.setData({
      histories:[]
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})