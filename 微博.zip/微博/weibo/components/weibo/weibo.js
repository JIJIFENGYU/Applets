// components/weibo/weibo.js

const app = getApp();
const db = wx.cloud.database();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    detailurl: {
      type: String,
      value: null
    },
    weibo: {
      type:Object,
      value:{}
    },
    showhandle: {
      type: Boolean,
      value: true
    }

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    onImageTap: function (event) {
      const imageIndex = event.target.dataset.imageindex;
      const curImageList = this.data.weibo.fileList;
      const curImage = curImageList[imageIndex];
      wx.previewImage({
        urls: curImageList,
        current: curImage
      })
    },

    onPraiseTap: function (event) {
      const that = this;
      const weibo = that.data.weibo;
      const openId = app.globalData.userInfo.openId;
      if (!weibo.isPraised) {
        wx.cloud.callFunction({
          name: "praise",
          data: {
            weiboId: weibo._id,
            praise: true
          },
          success: res => {
            if (!weibo.praiseList) {
              weibo.praiseList = [openId];
            } else {
              weibo.praiseList.push(openId);
            }
            weibo.isPraised = true;
            that.setData({
              weibo: weibo
            })
          }
        })
      } else {
        wx.cloud.callFunction({
          name: "praise",
          data: {
            weiboId: weibo._id,
            praise: false
          }
        }).then(res => {
          const newPraiseList = [];
          const praiseList = weibo.praiseList;
          praiseList.forEach((value, index) => {
            if (value != openId) {
              newPraiseList.push(value);
            }
          });
          weibo.praiseList = newPraiseList;
          weibo.isPraised = false;
          that.setData({
            weibo: weibo
          })
        })
      }

    },

    onMore: function (event) {
      console.log(event);
      const that = this;
      const weibo = that.data.weibo;
      const openId = app.globalData.userInfo.openId;
      const itemList = [];
      if (weibo.author.openId == openId) {
        itemList.push("删除")
      }
      itemList.push("收藏");
      if (weibo.author.openId == openId) {
        itemList.push("设为私密")
      }
      wx.showActionSheet({
        itemList: itemList,
        success: res => {
          const tapIndex = res.tapIndex;
          if (tapIndex == 0) {
          } else if (tapIndex == 1) {
          } else if (tapIndex == 2) {
          }

        }
      })
    }
  },

  

  lifetimes: {
    attached: function() {
      const windowWidth = wx.getSystemInfoSync().windowWidth;
      const weiboWidth = windowWidth - 30;
      const twoImageSize = (weiboWidth - 2.5) / 2;
      const threeImageSize = (weiboWidth - 2.5 * 2) / 3;
      this.setData({
        twoImageSize: twoImageSize,
        threeImageSize: threeImageSize
      })
    }
  }
})
