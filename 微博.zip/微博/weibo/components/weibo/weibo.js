// components/weibo/weibo.js

const app = getApp();
const db = wx.cloud.database();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    detailurl: {
      type: String,
      value: null
    },
    weibo: {
      type:Object,
      value:{}
    },
    showhandle: {
      type: Boolean,
      value: true
    }

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    onImageTap: function (event) {
      const imageIndex = event.target.dataset.imageindex;
      const curImageList = this.data.weibo.fileList;
      const curImage = curImageList[imageIndex];
      wx.previewImage({
        urls: curImageList,
        current: curImage
      })
    },

    onPraiseTap: function (event) {
      const that = this;
      const weibo = that.data.weibo;
      const openId = app.globalData.userInfo.openId;
      if (!weibo.isPraised) {
        wx.cloud.callFunction({
          name: "praise",
          data: {
            weiboId: weibo._id,
            praise: true
          },
          success: res => {
            if (!weibo.praiseList) {
              weibo.praiseList = [openId];
            } else {
              weibo.praiseList.push(openId);
            }
            weibo.isPraised = true;
            that.setData({
              weibo: weibo
            })
          }
        })
      } else {
        wx.cloud.callFunction({
          name: "praise",
          data: {
            weiboId: weibo._id,
            praise: false
          }
        }).then(res => {
          const newPraiseList = [];
          const praiseList = weibo.praiseList;
          praiseList.forEach((value, index) => {
            if (value != openId) {
              newPraiseList.push(value);
            }
          });
          weibo.praiseList = newPraiseList;
          weibo.isPraised = false;
          that.setData({
            weibo: weibo
          })
        })
      }

    },

    onMore: function (event) {
      console.log(event);
      const that = this;
      const weibo = that.data.weibo;
      let openId ;
      if (!app.globalData.userInfo) {
        wx.navigateTo({
          url: "../login/login"
        })  
        return;     
      } else {
        openId = app.globalData.userInfo.openId; 
      }
      const itemList = [];
      const status = weibo.status;
      if (weibo.author.openId == openId) {
        itemList.push("删除")
      }
      itemList.push("收藏");
      if (status == 1) {
        if (weibo.author.openId == openId) {
          itemList.push("设为私密")
        }
      } else {
        itemList.push("设为公开")
      }
      
      wx.showActionSheet({
        itemList: itemList,
        success: res => {
          const tapIndex = res.tapIndex;
          if (tapIndex == 0 && itemList.length == 3) {
            wx.cloud.callFunction({
              name: "deleteweibo",
              data: {
                weiboId: weibo._id
              }
            }).then(res => {   
              if (res.result.message === 'success') {
                wx.showToast({
                  title: '删除成功',
                  icon: 'none',
                  duration: 1000
                });
                const detail = {
                  weiboId: weibo._id
                }
                this.triggerEvent('delete', detail); 
              } else {
                wx.showToast({
                  title: '删除失败',
                  icon: 'none',
                  duration: 1000
                });
              }                 
              console.log("======" + JSON.stringify(res.result));
            })
          } else if (tapIndex == 2 && itemList.length == 3) {
            const newStatus = status == 1 ? 2 : 1;
            wx.cloud.callFunction({
              name: "changeWeiboStatus",
              data: {
                weiboId: weibo._id,
                status: newStatus
              }
            }).then(res => { 
              let title = '';
              if (res.result.message === 'success') {
                title = '操作成功';
                const detail = {
                  weiboId: weibo._id
                }
                this.triggerEvent('delete', detail); 
              } else {
                title = '操作失败'
              }
              wx.showToast({
                title: title,
                icon: 'none',
                duration: 1000
              })
            })
          } else if (tapIndex == 2) {
          }

        }
      })
    }
  },

  

  lifetimes: {
    attached: function() {
      const windowWidth = wx.getSystemInfoSync().windowWidth;
      const weiboWidth = windowWidth - 30;
      const twoImageSize = (weiboWidth - 2.5) / 2;
      const threeImageSize = (weiboWidth - 2.5 * 2) / 3;
      this.setData({
        twoImageSize: twoImageSize,
        threeImageSize: threeImageSize
      })
    }
  }
})
