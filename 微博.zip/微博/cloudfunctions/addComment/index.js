// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database();
const _ = db.command;

// 云函数入口函数
exports.main = async (event, context) => {
  const weiboId = event.weiboId;
  const weiboRes = await db.collection("weibo").doc(weiboId).get();
  const weibo = weiboRes.data;
  console.log(weibo);
  let newcomment;
  if (weibo.comment) {
    newcomment = weibo.comment + 1;   
  } else {
    newcomment = 1;
  }
  return await db.collection("weibo").doc(weiboId).update({
    data: {
      comment: newcomment
    }
  })
}