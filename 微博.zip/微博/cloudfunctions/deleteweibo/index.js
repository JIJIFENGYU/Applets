// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database();
const _ = db.command;

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  const openid = wxContext.OPENID;
  const weiboId = event.weiboId;

  const promise1 =  db.collection('weibo').doc(weiboId).remove();
  const promise2 = db.collection('comment').where({
    weiboid: weiboId
  }).remove();
  const tasks = [];
  tasks.push(promise1);
  tasks.push(promise2);
  let result;
  await Promise.all(tasks).then(res => {
    result =  {
      message: 'success'
    }
  }).catch( err => {
    result =  {
      message: 'fail'
    }
  });
  return result;
}